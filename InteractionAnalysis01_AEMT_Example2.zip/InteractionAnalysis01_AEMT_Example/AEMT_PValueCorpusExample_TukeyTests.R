#Start = Load AEAEMTDialFULL  -- Re-Analysis of the Full AEMT Corpus # 12 July 2019
#Proportions extraction, Tukey Test and P-Value Extraction per Speakers in the AEMT

#summary(AEMTDialFULL)
######################################################################
#Test with Level + Clear history console and Environment
######################################################################
### aemt01
######################################################################
aemt01 <- AEMTDialFULL[AEMTDialFULL$DialID=="aemt01",]
#summary(aemt01)
#Drop factor levels in a subsetted data frame we have to 'refactorize' them
aemt01$DialID <- factor(aemt01$DialID)
attach(aemt01)

Level <- factor(Level)
REALITY <- Reality < 1
REALITY  <- factor(REALITY)
DialogType <- ifelse( REALITY==TRUE, c("Actual"), c("Randomized"))
DialogType <- factor(DialogType)
Speakers <- factor(Speakers)
NSS <- (NGrams-SS)
NOS <- (NGrams-OS)
# eliminate eventual negative values in NOS and NSS
NOS[NOS < 0] <- 0
NSS[NSS < 0] <- 0

OSprop <- cbind(OS,NOS)
SSprop <- cbind(SS,NSS)

library(multcomp)
#glm(OSprop~DialogType*Speakers*Level,family = binomial)

OSfos <- interaction(DialogType,Speakers,Level)
OSmfos <- glm(OSprop~OSfos,family = binomial)
OSmfos.mc <- glht(OSmfos,linfct=mcp(OSfos="Tukey"), alternative="l")
# Addition to write the output of the test in a file
options(max.print=999999)
OSs <- summary(OSmfos.mc)
# residual deviance and residual
#1-pchisq(172500,124929)
#plot(summary(OSmfos.mc))
CIOSs <- confint(OSmfos)
CIOSTs <- confint(OSmfos.mc)

capture.output(OSs, file = "/home/justine/Desktop/AEMT/InteractionAnalysis_AEMT/AnalysisR/PValues/TukeyTestLevelaemt01_OS.txt")
capture.output(CIOSs, file = "/home/justine/Desktop/AEMT/InteractionAnalysis_AEMT/AnalysisR/ConfidenceIntervals/CIglm/CIaemt01_OS.txt")
capture.output(CIOSTs, file = "/home/justine/Desktop/AEMT/InteractionAnalysis_AEMT/AnalysisR/ConfidenceIntervals/CIglht/CIaemt01_OS.txt")

SSfos <- interaction(DialogType,Speakers,Level)
SSmfos <- glm(SSprop~SSfos,family = binomial)
SSmfos.mc <- glht(SSmfos,linfct=mcp(SSfos="Tukey"), alternative="l")
# Addition to write the output of the test in a file
options(max.print=999999) 
SSs <- summary(SSmfos.mc)

CISSs <- confint(SSmfos)
CISSTs <- confint(SSmfos.mc)

capture.output(SSs, file = "/home/justine/Desktop/AEMT/InteractionAnalysis_AEMT/AnalysisR/PValues/TukeyTestLevelaemt01_SS.txt")
capture.output(CISSs, file = "/home/justine/Desktop/AEMT/InteractionAnalysis_AEMT/AnalysisR/ConfidenceIntervals/CIglm/CIaemt01_SS.txt")
capture.output(CISSTs, file = "/home/justine/Desktop/AEMT/InteractionAnalysis_AEMT/AnalysisR/ConfidenceIntervals/CIglht/CIaemt01_SS.txt")
detach(aemt01)

rm(list=setdiff(ls(), "AEMTDialFULL"))
######################################################################
######################################################################
aemt01N1 <- AEMTDialFULL[AEMTDialFULL$DialID=="aemt01"&AEMTDialFULL$N==1,]
#summary(aemt01N1)
#Drop factor levels in a subsetted data frame we have to 'refactorize' them
aemt01N1$DialID <- factor(aemt01N1$DialID)
attach(aemt01N1)

Level <- factor(Level)
REALITY <- Reality < 1
REALITY  <- factor(REALITY)
DialogType <- ifelse( REALITY==TRUE, c("Actual"), c("Randomized"))
DialogType <- factor(DialogType)
Speakers <- factor(Speakers)
NSS <- (NGrams-SS)
NOS <- (NGrams-OS)
# eliminate eventual negative values in NOS and NSS
NOS[NOS < 0] <- 0
NSS[NSS < 0] <- 0

OSprop <- cbind(OS,NOS)
SSprop <- cbind(SS,NSS)

library(multcomp)
#glm(OSprop~DialogType*Speakers*Level,family = binomial)

OSfos <- interaction(DialogType,Speakers,Level)
OSmfos <- glm(OSprop~OSfos,family = binomial)
OSmfos.mc <- glht(OSmfos,linfct=mcp(OSfos="Tukey"), alternative="l")
# Addition to write the output of the test in a file
options(max.print=999999)
OSs <- summary(OSmfos.mc)
# residual deviance and residual
#1-pchisq(172500,124929)
#plot(summary(OSmfos.mc))
CIOSs <- confint(OSmfos)
CIOSTs <- confint(OSmfos.mc)

capture.output(OSs, file = "/home/justine/Desktop/AEMT/InteractionAnalysis_AEMT/AnalysisR/PValuesN1/TukeyTestLevelaemt01N1_OS.txt")
capture.output(CIOSs, file = "/home/justine/Desktop/AEMT/InteractionAnalysis_AEMT/AnalysisR/ConfidenceIntervals/CIglm/CIaemt01N1_OS.txt")
capture.output(CIOSTs, file = "/home/justine/Desktop/AEMT/InteractionAnalysis_AEMT/AnalysisR/ConfidenceIntervals/CIglht/CIaemt01N1_OS.txt")

SSfos <- interaction(DialogType,Speakers,Level)
SSmfos <- glm(SSprop~SSfos,family = binomial)
SSmfos.mc <- glht(SSmfos,linfct=mcp(SSfos="Tukey"), alternative="l")
# Addition to write the output of the test in a file
options(max.print=999999) 
SSs <- summary(SSmfos.mc)

CISSs <- confint(SSmfos)
CISSTs <- confint(SSmfos.mc)

capture.output(SSs, file = "/home/justine/Desktop/AEMT/InteractionAnalysis_AEMT/AnalysisR/PValuesN1/TukeyTestLevelaemt01N1_SS.txt")
capture.output(CISSs, file = "/home/justine/Desktop/AEMT/InteractionAnalysis_AEMT/AnalysisR/ConfidenceIntervals/CIglm/CIaemt01N1_SS.txt")
capture.output(CISSTs, file = "/home/justine/Desktop/AEMT/InteractionAnalysis_AEMT/AnalysisR/ConfidenceIntervals/CIglht/CIaemt01N1_SS.txt")
detach(aemt01N1)

rm(list=setdiff(ls(), "AEMTDialFULL"))
######################################################################
######################################################################
aemt01N2 <- AEMTDialFULL[AEMTDialFULL$DialID=="aemt01"&AEMTDialFULL$N==2,]
#summary(aemt01N2)
#Drop factor levels in a subsetted data frame we have to 'refactorize' them
aemt01N2$DialID <- factor(aemt01N2$DialID)
attach(aemt01N2)

Level <- factor(Level)
REALITY <- Reality < 1
REALITY  <- factor(REALITY)
DialogType <- ifelse( REALITY==TRUE, c("Actual"), c("Randomized"))
DialogType <- factor(DialogType)
Speakers <- factor(Speakers)
NSS <- (NGrams-SS)
NOS <- (NGrams-OS)
# eliminate eventual negative values in NOS and NSS
NOS[NOS < 0] <- 0
NSS[NSS < 0] <- 0

OSprop <- cbind(OS,NOS)
SSprop <- cbind(SS,NSS)

library(multcomp)
#glm(OSprop~DialogType*Speakers*Level,family = binomial)

OSfos <- interaction(DialogType,Speakers,Level)
OSmfos <- glm(OSprop~OSfos,family = binomial)
OSmfos.mc <- glht(OSmfos,linfct=mcp(OSfos="Tukey"), alternative="l")
# Addition to write the output of the test in a file
options(max.print=999999)
OSs <- summary(OSmfos.mc)
# residual deviance and residual
#1-pchisq(172500,124929)
#plot(summary(OSmfos.mc))
CIOSs <- confint(OSmfos)
CIOSTs <- confint(OSmfos.mc)

capture.output(OSs, file = "/home/justine/Desktop/AEMT/InteractionAnalysis_AEMT/AnalysisR/PValuesN2/TukeyTestLevelaemt01N2_OS.txt")
capture.output(CIOSs, file = "/home/justine/Desktop/AEMT/InteractionAnalysis_AEMT/AnalysisR/ConfidenceIntervals/CIglm/CIaemt01N2_OS.txt")
capture.output(CIOSTs, file = "/home/justine/Desktop/AEMT/InteractionAnalysis_AEMT/AnalysisR/ConfidenceIntervals/CIglht/CIaemt01N2_OS.txt")

SSfos <- interaction(DialogType,Speakers,Level)
SSmfos <- glm(SSprop~SSfos,family = binomial)
SSmfos.mc <- glht(SSmfos,linfct=mcp(SSfos="Tukey"), alternative="l")
# Addition to write the output of the test in a file
options(max.print=999999) 
SSs <- summary(SSmfos.mc)

CISSs <- confint(SSmfos)
CISSTs <- confint(SSmfos.mc)

capture.output(SSs, file = "/home/justine/Desktop/AEMT/InteractionAnalysis_AEMT/AnalysisR/PValuesN2/TukeyTestLevelaemt01N2_SS.txt")
capture.output(CISSs, file = "/home/justine/Desktop/AEMT/InteractionAnalysis_AEMT/AnalysisR/ConfidenceIntervals/CIglm/CIaemt01N2_SS.txt")
capture.output(CISSTs, file = "/home/justine/Desktop/AEMT/InteractionAnalysis_AEMT/AnalysisR/ConfidenceIntervals/CIglht/CIaemt01N2_SS.txt")
detach(aemt01N2)

rm(list=setdiff(ls(), "AEMTDialFULL"))
######################################################################
######################################################################
### aemt02
######################################################################
aemt02 <- AEMTDialFULL[AEMTDialFULL$DialID=="aemt02",]
#summary(aemt02)
#Drop factor levels in a subsetted data frame we have to 'refactorize' them
aemt02$DialID <- factor(aemt02$DialID)
attach(aemt02)

Level <- factor(Level)
REALITY <- Reality < 1
REALITY  <- factor(REALITY)
DialogType <- ifelse( REALITY==TRUE, c("Actual"), c("Randomized"))
DialogType <- factor(DialogType)
Speakers <- factor(Speakers)
NSS <- (NGrams-SS)
NOS <- (NGrams-OS)
# eliminate eventual negative values in NOS and NSS
NOS[NOS < 0] <- 0
NSS[NSS < 0] <- 0

OSprop <- cbind(OS,NOS)
SSprop <- cbind(SS,NSS)

library(multcomp)
#glm(OSprop~DialogType*Speakers*Level,family = binomial)

OSfos <- interaction(DialogType,Speakers,Level)
OSmfos <- glm(OSprop~OSfos,family = binomial)
OSmfos.mc <- glht(OSmfos,linfct=mcp(OSfos="Tukey"), alternative="l")
# Addition to write the output of the test in a file
options(max.print=999999)
OSs <- summary(OSmfos.mc)
# residual deviance and residual
#1-pchisq(172500,124929)
#plot(summary(OSmfos.mc))
CIOSs <- confint(OSmfos)
CIOSTs <- confint(OSmfos.mc)

capture.output(OSs, file = "/home/justine/Desktop/AEMT/InteractionAnalysis_AEMT/AnalysisR/PValues/TukeyTestLevelaemt02_OS.txt")
capture.output(CIOSs, file = "/home/justine/Desktop/AEMT/InteractionAnalysis_AEMT/AnalysisR/ConfidenceIntervals/CIglm/CIaemt02_OS.txt")
capture.output(CIOSTs, file = "/home/justine/Desktop/AEMT/InteractionAnalysis_AEMT/AnalysisR/ConfidenceIntervals/CIglht/CIaemt02_OS.txt")

SSfos <- interaction(DialogType,Speakers,Level)
SSmfos <- glm(SSprop~SSfos,family = binomial)
SSmfos.mc <- glht(SSmfos,linfct=mcp(SSfos="Tukey"), alternative="l")
# Addition to write the output of the test in a file
options(max.print=999999) 
SSs <- summary(SSmfos.mc)

CISSs <- confint(SSmfos)
CISSTs <- confint(SSmfos.mc)

capture.output(SSs, file = "/home/justine/Desktop/AEMT/InteractionAnalysis_AEMT/AnalysisR/PValues/TukeyTestLevelaemt02_SS.txt")
capture.output(CISSs, file = "/home/justine/Desktop/AEMT/InteractionAnalysis_AEMT/AnalysisR/ConfidenceIntervals/CIglm/CIaemt02_SS.txt")
capture.output(CISSTs, file = "/home/justine/Desktop/AEMT/InteractionAnalysis_AEMT/AnalysisR/ConfidenceIntervals/CIglht/CIaemt02_SS.txt")
detach(aemt02)

rm(list=setdiff(ls(), "AEMTDialFULL"))
######################################################################
######################################################################
aemt02N1 <- AEMTDialFULL[AEMTDialFULL$DialID=="aemt02"&AEMTDialFULL$N==1,]
#summary(aemt02N1)
#Drop factor levels in a subsetted data frame we have to 'refactorize' them
aemt02N1$DialID <- factor(aemt02N1$DialID)
attach(aemt02N1)

Level <- factor(Level)
REALITY <- Reality < 1
REALITY  <- factor(REALITY)
DialogType <- ifelse( REALITY==TRUE, c("Actual"), c("Randomized"))
DialogType <- factor(DialogType)
Speakers <- factor(Speakers)
NSS <- (NGrams-SS)
NOS <- (NGrams-OS)
# eliminate eventual negative values in NOS and NSS
NOS[NOS < 0] <- 0
NSS[NSS < 0] <- 0

OSprop <- cbind(OS,NOS)
SSprop <- cbind(SS,NSS)

library(multcomp)
#glm(OSprop~DialogType*Speakers*Level,family = binomial)

OSfos <- interaction(DialogType,Speakers,Level)
OSmfos <- glm(OSprop~OSfos,family = binomial)
OSmfos.mc <- glht(OSmfos,linfct=mcp(OSfos="Tukey"), alternative="l")
# Addition to write the output of the test in a file
options(max.print=999999)
OSs <- summary(OSmfos.mc)
# residual deviance and residual
#1-pchisq(172500,124929)
#plot(summary(OSmfos.mc))
CIOSs <- confint(OSmfos)
CIOSTs <- confint(OSmfos.mc)

capture.output(OSs, file = "/home/justine/Desktop/AEMT/InteractionAnalysis_AEMT/AnalysisR/PValuesN1/TukeyTestLevelaemt02N1_OS.txt")
capture.output(CIOSs, file = "/home/justine/Desktop/AEMT/InteractionAnalysis_AEMT/AnalysisR/ConfidenceIntervals/CIglm/CIaemt02N1_OS.txt")
capture.output(CIOSTs, file = "/home/justine/Desktop/AEMT/InteractionAnalysis_AEMT/AnalysisR/ConfidenceIntervals/CIglht/CIaemt02N1_OS.txt")

SSfos <- interaction(DialogType,Speakers,Level)
SSmfos <- glm(SSprop~SSfos,family = binomial)
SSmfos.mc <- glht(SSmfos,linfct=mcp(SSfos="Tukey"), alternative="l")
# Addition to write the output of the test in a file
options(max.print=999999) 
SSs <- summary(SSmfos.mc)

CISSs <- confint(SSmfos)
CISSTs <- confint(SSmfos.mc)

capture.output(SSs, file = "/home/justine/Desktop/AEMT/InteractionAnalysis_AEMT/AnalysisR/PValuesN1/TukeyTestLevelaemt02N1_SS.txt")
capture.output(CISSs, file = "/home/justine/Desktop/AEMT/InteractionAnalysis_AEMT/AnalysisR/ConfidenceIntervals/CIglm/CIaemt02N1_SS.txt")
capture.output(CISSTs, file = "/home/justine/Desktop/AEMT/InteractionAnalysis_AEMT/AnalysisR/ConfidenceIntervals/CIglht/CIaemt02N1_SS.txt")
detach(aemt02N1)

rm(list=setdiff(ls(), "AEMTDialFULL"))
######################################################################
######################################################################
aemt02N2 <- AEMTDialFULL[AEMTDialFULL$DialID=="aemt02"&AEMTDialFULL$N==2,]
#summary(aemt02N2)
#Drop factor levels in a subsetted data frame we have to 'refactorize' them
aemt02N2$DialID <- factor(aemt02N2$DialID)
attach(aemt02N2)

Level <- factor(Level)
REALITY <- Reality < 1
REALITY  <- factor(REALITY)
DialogType <- ifelse( REALITY==TRUE, c("Actual"), c("Randomized"))
DialogType <- factor(DialogType)
Speakers <- factor(Speakers)
NSS <- (NGrams-SS)
NOS <- (NGrams-OS)
# eliminate eventual negative values in NOS and NSS
NOS[NOS < 0] <- 0
NSS[NSS < 0] <- 0

OSprop <- cbind(OS,NOS)
SSprop <- cbind(SS,NSS)

library(multcomp)
#glm(OSprop~DialogType*Speakers*Level,family = binomial)

OSfos <- interaction(DialogType,Speakers,Level)
OSmfos <- glm(OSprop~OSfos,family = binomial)
OSmfos.mc <- glht(OSmfos,linfct=mcp(OSfos="Tukey"), alternative="l")
# Addition to write the output of the test in a file
options(max.print=999999)
OSs <- summary(OSmfos.mc)
# residual deviance and residual
#1-pchisq(172500,124929)
#plot(summary(OSmfos.mc))
CIOSs <- confint(OSmfos)
CIOSTs <- confint(OSmfos.mc)

capture.output(OSs, file = "/home/justine/Desktop/AEMT/InteractionAnalysis_AEMT/AnalysisR/PValuesN2/TukeyTestLevelaemt02N2_OS.txt")
capture.output(CIOSs, file = "/home/justine/Desktop/AEMT/InteractionAnalysis_AEMT/AnalysisR/ConfidenceIntervals/CIglm/CIaemt02N2_OS.txt")
capture.output(CIOSTs, file = "/home/justine/Desktop/AEMT/InteractionAnalysis_AEMT/AnalysisR/ConfidenceIntervals/CIglht/CIaemt02N2_OS.txt")

SSfos <- interaction(DialogType,Speakers,Level)
SSmfos <- glm(SSprop~SSfos,family = binomial)
SSmfos.mc <- glht(SSmfos,linfct=mcp(SSfos="Tukey"), alternative="l")
# Addition to write the output of the test in a file
options(max.print=999999) 
SSs <- summary(SSmfos.mc)

CISSs <- confint(SSmfos)
CISSTs <- confint(SSmfos.mc)

capture.output(SSs, file = "/home/justine/Desktop/AEMT/InteractionAnalysis_AEMT/AnalysisR/PValuesN2/TukeyTestLevelaemt02N2_SS.txt")
capture.output(CISSs, file = "/home/justine/Desktop/AEMT/InteractionAnalysis_AEMT/AnalysisR/ConfidenceIntervals/CIglm/CIaemt02N2_SS.txt")
capture.output(CISSTs, file = "/home/justine/Desktop/AEMT/InteractionAnalysis_AEMT/AnalysisR/ConfidenceIntervals/CIglht/CIaemt02N2_SS.txt")
detach(aemt02N2)

rm(list=setdiff(ls(), "AEMTDialFULL"))
######################################################################

######################################################################

######################################################################
######################################################################
#        UNDERCHANCE
######################################################################
### aemt01
######################################################################
aemt01 <- AEMTDialFULL[AEMTDialFULL$DialID=="aemt01",]
#summary(aemt01)
#Drop factor levels in a subsetted data frame we have to 'refactorize' them
aemt01$DialID <- factor(aemt01$DialID)
attach(aemt01)

Level <- factor(Level)
REALITY <- Reality < 1
REALITY  <- factor(REALITY)
DialogType <- ifelse( REALITY==TRUE, c("Actual"), c("Randomized"))
DialogType <- factor(DialogType)
Speakers <- factor(Speakers)
NSS <- (NGrams-SS)
NOS <- (NGrams-OS)
# eliminate eventual negative values in NOS and NSS
NOS[NOS < 0] <- 0
NSS[NSS < 0] <- 0

OSprop <- cbind(OS,NOS)
SSprop <- cbind(SS,NSS)

library(multcomp)
#glm(OSprop~DialogType*Speakers*Level,family = binomial)

OSfos <- interaction(DialogType,Speakers,Level)
OSmfos <- glm(OSprop~OSfos,family = binomial)
OSmfos.mc <- glht(OSmfos,linfct=mcp(OSfos="Tukey"), alternative="g")
# Addition to write the output of the test in a file
options(max.print=999999)
OSs <- summary(OSmfos.mc)
# residual deviance and residual
#1-pchisq(172500,124929)
#plot(summary(OSmfos.mc))
CIOSs <- confint(OSmfos)
CIOSTs <- confint(OSmfos.mc)

capture.output(OSs, file = "/home/justine/Desktop/AEMT/InteractionAnalysis_AEMT/AnalysisRUnder/PValues/TukeyTestLevelaemt01_OS.txt")
capture.output(CIOSs, file = "/home/justine/Desktop/AEMT/InteractionAnalysis_AEMT/AnalysisRUnder/ConfidenceIntervals/CIglm/CIaemt01_OS.txt")
capture.output(CIOSTs, file = "/home/justine/Desktop/AEMT/InteractionAnalysis_AEMT/AnalysisRUnder/ConfidenceIntervals/CIglht/CIaemt01_OS.txt")

SSfos <- interaction(DialogType,Speakers,Level)
SSmfos <- glm(SSprop~SSfos,family = binomial)
SSmfos.mc <- glht(SSmfos,linfct=mcp(SSfos="Tukey"), alternative="g")
# Addition to write the output of the test in a file
options(max.print=999999) 
SSs <- summary(SSmfos.mc)

CISSs <- confint(SSmfos)
CISSTs <- confint(SSmfos.mc)

capture.output(SSs, file = "/home/justine/Desktop/AEMT/InteractionAnalysis_AEMT/AnalysisRUnder/PValues/TukeyTestLevelaemt01_SS.txt")
capture.output(CISSs, file = "/home/justine/Desktop/AEMT/InteractionAnalysis_AEMT/AnalysisRUnder/ConfidenceIntervals/CIglm/CIaemt01_SS.txt")
capture.output(CISSTs, file = "/home/justine/Desktop/AEMT/InteractionAnalysis_AEMT/AnalysisRUnder/ConfidenceIntervals/CIglht/CIaemt01_SS.txt")
detach(aemt01)

rm(list=setdiff(ls(), "AEMTDialFULL"))
######################################################################
######################################################################
aemt01N1 <- AEMTDialFULL[AEMTDialFULL$DialID=="aemt01"&AEMTDialFULL$N==1,]
#summary(aemt01N1)
#Drop factor levels in a subsetted data frame we have to 'refactorize' them
aemt01N1$DialID <- factor(aemt01N1$DialID)
attach(aemt01N1)

Level <- factor(Level)
REALITY <- Reality < 1
REALITY  <- factor(REALITY)
DialogType <- ifelse( REALITY==TRUE, c("Actual"), c("Randomized"))
DialogType <- factor(DialogType)
Speakers <- factor(Speakers)
NSS <- (NGrams-SS)
NOS <- (NGrams-OS)
# eliminate eventual negative values in NOS and NSS
NOS[NOS < 0] <- 0
NSS[NSS < 0] <- 0

OSprop <- cbind(OS,NOS)
SSprop <- cbind(SS,NSS)

library(multcomp)
#glm(OSprop~DialogType*Speakers*Level,family = binomial)

OSfos <- interaction(DialogType,Speakers,Level)
OSmfos <- glm(OSprop~OSfos,family = binomial)
OSmfos.mc <- glht(OSmfos,linfct=mcp(OSfos="Tukey"), alternative="g")
# Addition to write the output of the test in a file
options(max.print=999999)
OSs <- summary(OSmfos.mc)
# residual deviance and residual
#1-pchisq(172500,124929)
#plot(summary(OSmfos.mc))
CIOSs <- confint(OSmfos)
CIOSTs <- confint(OSmfos.mc)

capture.output(OSs, file = "/home/justine/Desktop/AEMT/InteractionAnalysis_AEMT/AnalysisRUnder/PValuesN1/TukeyTestLevelaemt01N1_OS.txt")
capture.output(CIOSs, file = "/home/justine/Desktop/AEMT/InteractionAnalysis_AEMT/AnalysisRUnder/ConfidenceIntervals/CIglm/CIaemt01N1_OS.txt")
capture.output(CIOSTs, file = "/home/justine/Desktop/AEMT/InteractionAnalysis_AEMT/AnalysisRUnder/ConfidenceIntervals/CIglht/CIaemt01N1_OS.txt")

SSfos <- interaction(DialogType,Speakers,Level)
SSmfos <- glm(SSprop~SSfos,family = binomial)
SSmfos.mc <- glht(SSmfos,linfct=mcp(SSfos="Tukey"), alternative="g")
# Addition to write the output of the test in a file
options(max.print=999999) 
SSs <- summary(SSmfos.mc)

CISSs <- confint(SSmfos)
CISSTs <- confint(SSmfos.mc)

capture.output(SSs, file = "/home/justine/Desktop/AEMT/InteractionAnalysis_AEMT/AnalysisRUnder/PValuesN1/TukeyTestLevelaemt01N1_SS.txt")
capture.output(CISSs, file = "/home/justine/Desktop/AEMT/InteractionAnalysis_AEMT/AnalysisRUnder/ConfidenceIntervals/CIglm/CIaemt01N1_SS.txt")
capture.output(CISSTs, file = "/home/justine/Desktop/AEMT/InteractionAnalysis_AEMT/AnalysisRUnder/ConfidenceIntervals/CIglht/CIaemt01N1_SS.txt")
detach(aemt01N1)

rm(list=setdiff(ls(), "AEMTDialFULL"))
######################################################################
######################################################################
aemt01N2 <- AEMTDialFULL[AEMTDialFULL$DialID=="aemt01"&AEMTDialFULL$N==2,]
#summary(aemt01N2)
#Drop factor levels in a subsetted data frame we have to 'refactorize' them
aemt01N2$DialID <- factor(aemt01N2$DialID)
attach(aemt01N2)

Level <- factor(Level)
REALITY <- Reality < 1
REALITY  <- factor(REALITY)
DialogType <- ifelse( REALITY==TRUE, c("Actual"), c("Randomized"))
DialogType <- factor(DialogType)
Speakers <- factor(Speakers)
NSS <- (NGrams-SS)
NOS <- (NGrams-OS)
# eliminate eventual negative values in NOS and NSS
NOS[NOS < 0] <- 0
NSS[NSS < 0] <- 0

OSprop <- cbind(OS,NOS)
SSprop <- cbind(SS,NSS)

library(multcomp)
#glm(OSprop~DialogType*Speakers*Level,family = binomial)

OSfos <- interaction(DialogType,Speakers,Level)
OSmfos <- glm(OSprop~OSfos,family = binomial)
OSmfos.mc <- glht(OSmfos,linfct=mcp(OSfos="Tukey"), alternative="g")
# Addition to write the output of the test in a file
options(max.print=999999)
OSs <- summary(OSmfos.mc)
# residual deviance and residual
#1-pchisq(172500,124929)
#plot(summary(OSmfos.mc))
CIOSs <- confint(OSmfos)
CIOSTs <- confint(OSmfos.mc)

capture.output(OSs, file = "/home/justine/Desktop/AEMT/InteractionAnalysis_AEMT/AnalysisRUnder/PValuesN2/TukeyTestLevelaemt01N2_OS.txt")
capture.output(CIOSs, file = "/home/justine/Desktop/AEMT/InteractionAnalysis_AEMT/AnalysisRUnder/ConfidenceIntervals/CIglm/CIaemt01N2_OS.txt")
capture.output(CIOSTs, file = "/home/justine/Desktop/AEMT/InteractionAnalysis_AEMT/AnalysisRUnder/ConfidenceIntervals/CIglht/CIaemt01N2_OS.txt")

SSfos <- interaction(DialogType,Speakers,Level)
SSmfos <- glm(SSprop~SSfos,family = binomial)
SSmfos.mc <- glht(SSmfos,linfct=mcp(SSfos="Tukey"), alternative="g")
# Addition to write the output of the test in a file
options(max.print=999999) 
SSs <- summary(SSmfos.mc)

CISSs <- confint(SSmfos)
CISSTs <- confint(SSmfos.mc)

capture.output(SSs, file = "/home/justine/Desktop/AEMT/InteractionAnalysis_AEMT/AnalysisRUnder/PValuesN2/TukeyTestLevelaemt01N2_SS.txt")
capture.output(CISSs, file = "/home/justine/Desktop/AEMT/InteractionAnalysis_AEMT/AnalysisRUnder/ConfidenceIntervals/CIglm/CIaemt01N2_SS.txt")
capture.output(CISSTs, file = "/home/justine/Desktop/AEMT/InteractionAnalysis_AEMT/AnalysisRUnder/ConfidenceIntervals/CIglht/CIaemt01N2_SS.txt")
detach(aemt01N2)

rm(list=setdiff(ls(), "AEMTDialFULL"))
######################################################################
######################################################################
### aemt02
######################################################################
aemt02 <- AEMTDialFULL[AEMTDialFULL$DialID=="aemt02",]
#summary(aemt02)
#Drop factor levels in a subsetted data frame we have to 'refactorize' them
aemt02$DialID <- factor(aemt02$DialID)
attach(aemt02)

Level <- factor(Level)
REALITY <- Reality < 1
REALITY  <- factor(REALITY)
DialogType <- ifelse( REALITY==TRUE, c("Actual"), c("Randomized"))
DialogType <- factor(DialogType)
Speakers <- factor(Speakers)
NSS <- (NGrams-SS)
NOS <- (NGrams-OS)
# eliminate eventual negative values in NOS and NSS
NOS[NOS < 0] <- 0
NSS[NSS < 0] <- 0

OSprop <- cbind(OS,NOS)
SSprop <- cbind(SS,NSS)

library(multcomp)
#glm(OSprop~DialogType*Speakers*Level,family = binomial)

OSfos <- interaction(DialogType,Speakers,Level)
OSmfos <- glm(OSprop~OSfos,family = binomial)
OSmfos.mc <- glht(OSmfos,linfct=mcp(OSfos="Tukey"), alternative="g")
# Addition to write the output of the test in a file
options(max.print=999999)
OSs <- summary(OSmfos.mc)
# residual deviance and residual
#1-pchisq(172500,124929)
#plot(summary(OSmfos.mc))
CIOSs <- confint(OSmfos)
CIOSTs <- confint(OSmfos.mc)

capture.output(OSs, file = "/home/justine/Desktop/AEMT/InteractionAnalysis_AEMT/AnalysisRUnder/PValues/TukeyTestLevelaemt02_OS.txt")
capture.output(CIOSs, file = "/home/justine/Desktop/AEMT/InteractionAnalysis_AEMT/AnalysisRUnder/ConfidenceIntervals/CIglm/CIaemt02_OS.txt")
capture.output(CIOSTs, file = "/home/justine/Desktop/AEMT/InteractionAnalysis_AEMT/AnalysisRUnder/ConfidenceIntervals/CIglht/CIaemt02_OS.txt")

SSfos <- interaction(DialogType,Speakers,Level)
SSmfos <- glm(SSprop~SSfos,family = binomial)
SSmfos.mc <- glht(SSmfos,linfct=mcp(SSfos="Tukey"), alternative="g")
# Addition to write the output of the test in a file
options(max.print=999999) 
SSs <- summary(SSmfos.mc)

CISSs <- confint(SSmfos)
CISSTs <- confint(SSmfos.mc)

capture.output(SSs, file = "/home/justine/Desktop/AEMT/InteractionAnalysis_AEMT/AnalysisRUnder/PValues/TukeyTestLevelaemt02_SS.txt")
capture.output(CISSs, file = "/home/justine/Desktop/AEMT/InteractionAnalysis_AEMT/AnalysisRUnder/ConfidenceIntervals/CIglm/CIaemt02_SS.txt")
capture.output(CISSTs, file = "/home/justine/Desktop/AEMT/InteractionAnalysis_AEMT/AnalysisRUnder/ConfidenceIntervals/CIglht/CIaemt02_SS.txt")
detach(aemt02)

rm(list=setdiff(ls(), "AEMTDialFULL"))
######################################################################
######################################################################
aemt02N1 <- AEMTDialFULL[AEMTDialFULL$DialID=="aemt02"&AEMTDialFULL$N==1,]
#summary(aemt02N1)
#Drop factor levels in a subsetted data frame we have to 'refactorize' them
aemt02N1$DialID <- factor(aemt02N1$DialID)
attach(aemt02N1)

Level <- factor(Level)
REALITY <- Reality < 1
REALITY  <- factor(REALITY)
DialogType <- ifelse( REALITY==TRUE, c("Actual"), c("Randomized"))
DialogType <- factor(DialogType)
Speakers <- factor(Speakers)
NSS <- (NGrams-SS)
NOS <- (NGrams-OS)
# eliminate eventual negative values in NOS and NSS
NOS[NOS < 0] <- 0
NSS[NSS < 0] <- 0

OSprop <- cbind(OS,NOS)
SSprop <- cbind(SS,NSS)

library(multcomp)
#glm(OSprop~DialogType*Speakers*Level,family = binomial)

OSfos <- interaction(DialogType,Speakers,Level)
OSmfos <- glm(OSprop~OSfos,family = binomial)
OSmfos.mc <- glht(OSmfos,linfct=mcp(OSfos="Tukey"), alternative="g")
# Addition to write the output of the test in a file
options(max.print=999999)
OSs <- summary(OSmfos.mc)
# residual deviance and residual
#1-pchisq(172500,124929)
#plot(summary(OSmfos.mc))
CIOSs <- confint(OSmfos)
CIOSTs <- confint(OSmfos.mc)

capture.output(OSs, file = "/home/justine/Desktop/AEMT/InteractionAnalysis_AEMT/AnalysisRUnder/PValuesN1/TukeyTestLevelaemt02N1_OS.txt")
capture.output(CIOSs, file = "/home/justine/Desktop/AEMT/InteractionAnalysis_AEMT/AnalysisRUnder/ConfidenceIntervals/CIglm/CIaemt02N1_OS.txt")
capture.output(CIOSTs, file = "/home/justine/Desktop/AEMT/InteractionAnalysis_AEMT/AnalysisRUnder/ConfidenceIntervals/CIglht/CIaemt02N1_OS.txt")

SSfos <- interaction(DialogType,Speakers,Level)
SSmfos <- glm(SSprop~SSfos,family = binomial)
SSmfos.mc <- glht(SSmfos,linfct=mcp(SSfos="Tukey"), alternative="g")
# Addition to write the output of the test in a file
options(max.print=999999) 
SSs <- summary(SSmfos.mc)

CISSs <- confint(SSmfos)
CISSTs <- confint(SSmfos.mc)

capture.output(SSs, file = "/home/justine/Desktop/AEMT/InteractionAnalysis_AEMT/AnalysisRUnder/PValuesN1/TukeyTestLevelaemt02N1_SS.txt")
capture.output(CISSs, file = "/home/justine/Desktop/AEMT/InteractionAnalysis_AEMT/AnalysisRUnder/ConfidenceIntervals/CIglm/CIaemt02N1_SS.txt")
capture.output(CISSTs, file = "/home/justine/Desktop/AEMT/InteractionAnalysis_AEMT/AnalysisRUnder/ConfidenceIntervals/CIglht/CIaemt02N1_SS.txt")
detach(aemt02N1)

rm(list=setdiff(ls(), "AEMTDialFULL"))
######################################################################
######################################################################
aemt02N2 <- AEMTDialFULL[AEMTDialFULL$DialID=="aemt02"&AEMTDialFULL$N==2,]
#summary(aemt02N2)
#Drop factor levels in a subsetted data frame we have to 'refactorize' them
aemt02N2$DialID <- factor(aemt02N2$DialID)
attach(aemt02N2)

Level <- factor(Level)
REALITY <- Reality < 1
REALITY  <- factor(REALITY)
DialogType <- ifelse( REALITY==TRUE, c("Actual"), c("Randomized"))
DialogType <- factor(DialogType)
Speakers <- factor(Speakers)
NSS <- (NGrams-SS)
NOS <- (NGrams-OS)
# eliminate eventual negative values in NOS and NSS
NOS[NOS < 0] <- 0
NSS[NSS < 0] <- 0

OSprop <- cbind(OS,NOS)
SSprop <- cbind(SS,NSS)

library(multcomp)
#glm(OSprop~DialogType*Speakers*Level,family = binomial)

OSfos <- interaction(DialogType,Speakers,Level)
OSmfos <- glm(OSprop~OSfos,family = binomial)
OSmfos.mc <- glht(OSmfos,linfct=mcp(OSfos="Tukey"), alternative="g")
# Addition to write the output of the test in a file
options(max.print=999999)
OSs <- summary(OSmfos.mc)
# residual deviance and residual
#1-pchisq(172500,124929)
#plot(summary(OSmfos.mc))
CIOSs <- confint(OSmfos)
CIOSTs <- confint(OSmfos.mc)

capture.output(OSs, file = "/home/justine/Desktop/AEMT/InteractionAnalysis_AEMT/AnalysisRUnder/PValuesN2/TukeyTestLevelaemt02N2_OS.txt")
capture.output(CIOSs, file = "/home/justine/Desktop/AEMT/InteractionAnalysis_AEMT/AnalysisRUnder/ConfidenceIntervals/CIglm/CIaemt02N2_OS.txt")
capture.output(CIOSTs, file = "/home/justine/Desktop/AEMT/InteractionAnalysis_AEMT/AnalysisRUnder/ConfidenceIntervals/CIglht/CIaemt02N2_OS.txt")

SSfos <- interaction(DialogType,Speakers,Level)
SSmfos <- glm(SSprop~SSfos,family = binomial)
SSmfos.mc <- glht(SSmfos,linfct=mcp(SSfos="Tukey"), alternative="g")
# Addition to write the output of the test in a file
options(max.print=999999) 
SSs <- summary(SSmfos.mc)

CISSs <- confint(SSmfos)
CISSTs <- confint(SSmfos.mc)

capture.output(SSs, file = "/home/justine/Desktop/AEMT/InteractionAnalysis_AEMT/AnalysisRUnder/PValuesN2/TukeyTestLevelaemt02N2_SS.txt")
capture.output(CISSs, file = "/home/justine/Desktop/AEMT/InteractionAnalysis_AEMT/AnalysisRUnder/ConfidenceIntervals/CIglm/CIaemt02N2_SS.txt")
capture.output(CISSTs, file = "/home/justine/Desktop/AEMT/InteractionAnalysis_AEMT/AnalysisRUnder/ConfidenceIntervals/CIglht/CIaemt02N2_SS.txt")
detach(aemt02N2)

rm(list=setdiff(ls(), "AEMTDialFULL"))
######################################################################
