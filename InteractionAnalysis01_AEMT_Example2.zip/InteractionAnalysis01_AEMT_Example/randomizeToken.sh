#!/bin/bash

perl ./transcriptrandomizer.5.pl -i Dialogue/aemt01/AnalysisToken/aemt01.txt.iy.p0.c1.fmtd

perl ./transcriptrandomizer.5.pl -i Dialogue/aemt02/AnalysisToken/aemt02.txt.iy.p0.c1.fmtd
