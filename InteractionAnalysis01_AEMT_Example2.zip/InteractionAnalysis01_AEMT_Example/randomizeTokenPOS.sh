#!/bin/bash

perl ./transcriptrandomizer.5.pl -i Dialogue/aemt01/AnalysisToken+POS/aemt01-token-POS.iy.p0.c1.fmtd

perl ./transcriptrandomizer.5.pl -i Dialogue/aemt02/AnalysisToken+POS/aemt02-token-POS.iy.p0.c1.fmtd
