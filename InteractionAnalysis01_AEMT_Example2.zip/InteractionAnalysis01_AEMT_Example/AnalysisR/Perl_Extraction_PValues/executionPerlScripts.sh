#!/bin/bash

perl ./pValuesMTaemt01_OS.pl

perl ./pValuesMTaemt01_OSN1.pl

perl ./pValuesMTaemt01_OSN2.pl

perl ./pValuesMTaemt01_SS.pl

perl ./pValuesMTaemt01_SSN1.pl

perl ./pValuesMTaemt01_SSN2.pl

perl ./pValuesMTaemt02_OS.pl

perl ./pValuesMTaemt02_OSN1.pl

perl ./pValuesMTaemt02_OSN2.pl

perl ./pValuesMTaemt02_SS.pl

perl ./pValuesMTaemt02_SSN1.pl

perl ./pValuesMTaemt02_SSN2.pl

