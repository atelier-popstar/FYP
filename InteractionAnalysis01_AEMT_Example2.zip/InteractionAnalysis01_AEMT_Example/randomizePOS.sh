#!/bin/bash

perl ./transcriptrandomizer.5.pl -i Dialogue/aemt01/AnalysisPOS/aemt01-POS.iy.p0.c1.fmtd

perl ./transcriptrandomizer.5.pl -i Dialogue/aemt02/AnalysisPOS/aemt02-POS.iy.p0.c1.fmtd
