#!/bin/bash

perl ./transcriptrandomizer.5.pl -i Dialogue/aemt01/AnalysisLemma/aemt01-lemma.iy.p0.c1.fmtd

perl ./transcriptrandomizer.5.pl -i Dialogue/aemt02/AnalysisLemma/aemt02-lemma.iy.p0.c1.fmtd
