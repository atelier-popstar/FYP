#!/bin/bash

perl ./transcriptrandomizer.5.pl -i Dialogue/aemt01/AnalysisLemma+POS/aemt01-lemma-POS.iy.p0.c1.fmtd

perl ./transcriptrandomizer.5.pl -i Dialogue/aemt02/AnalysisLemma+POS/aemt02-lemma-POS.iy.p0.c1.fmtd
